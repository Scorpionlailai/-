"""Two detached serial workers; preflight and complete each model before next case."""
import argparse,fcntl,json,subprocess,sys,time,traceback
from pathlib import Path
from run import ROOT,DATASETS,SCENES,MODELS,write,summarize

def worker(slot):
    handle=(ROOT/f'worker_{slot}.lock').open('a');fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB)
    cases=[f'{d}/{s}/{m}' for d in DATASETS for s in SCENES for m in MODELS][slot::2]
    (ROOT/'logs').mkdir(exist_ok=True)
    for key in cases:
        if (ROOT/'STOP').exists():
            write(ROOT/f'worker_{slot}_status.json',dict(status='stopped_by_marker'));return
        write(ROOT/f'worker_{slot}_status.json',dict(status='running',case=key,gpu=slot,time=time.time()))
        if (ROOT/'runs'/key/'complete.json').exists():continue
        with (ROOT/'logs'/(key.replace('/','__')+'.log')).open('a') as log:
            args=[sys.executable,str(Path(__file__).parent/'run.py'),'--case',key,'--device',f'cuda:{slot}']
            try:
                # Each dataset/model configuration also passes native-specific smoke before full train.
                if not (ROOT/'smoke'/key/'complete.json').exists():subprocess.run(args+['--smoke'],stdout=log,stderr=subprocess.STDOUT,check=True)
                subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,check=True)
            except Exception:
                with (ROOT/'failures.jsonl').open('a') as f:f.write(json.dumps(dict(case=key,error=traceback.format_exc(),time=time.time()))+'\n')
        summarize()
    write(ROOT/f'worker_{slot}_status.json',dict(status='finished',gpu=slot));summarize()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--slot',type=int,choices=[0,1],required=True);worker(p.parse_args().slot)
