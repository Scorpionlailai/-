import importlib,sys,types
from pathlib import Path
import pytest
import torch
from models import Initializer,VENDOR

@pytest.mark.parametrize('name',['SAITS','ModernTCN','TimeMixerPP'])
def test_native_missing_and_hidden_input_invariance(name):
    torch.set_num_threads(2);torch.manual_seed(2021)
    m=Initializer(name,'ETTh1',7,torch.device('cpu')).eval()
    truth=torch.randn(2,96,7);valid=torch.ones_like(truth,dtype=torch.bool);valid[:,20:25,3]=False
    seen=(torch.rand_like(truth)>.7)&valid;seen[:,:,0]=False
    safe=torch.where(seen,truth,0.)
    pred=m(safe,seen)
    assert pred.shape==truth.shape and torch.isfinite(pred).all()
    assert torch.equal(pred[seen],truth[seen])
    assert torch.equal(pred,m(torch.where(seen,truth,torch.full_like(truth,float('nan'))),seen))
    changed=truth.clone();changed[~valid]=1000.
    torch.testing.assert_close(m.loss(truth,seen,valid),m.loss(changed,seen,valid),atol=0,rtol=0)
    loss=m.loss(truth,seen,valid);loss.backward()
    assert all(torch.isfinite(p.grad).all() for p in m.parameters() if p.grad is not None)
    assert any(p.grad is not None and bool((p.grad!=0).any()) for p in m.parameters())

def test_modern_guard_preserves_original_nonempty_forward():
    torch.set_num_threads(2);torch.manual_seed(2021)
    m=Initializer('ModernTCN','ETTh1',7,torch.device('cpu')).eval()
    path=VENDOR/'moderntcn/models/ModernTCN.py'
    text=path.read_text().replace('from layers.RevIN import RevIN','from _new_moderntcn.layers.RevIN import RevIN').replace('from models.ModernTCN_Layer import','from _new_moderntcn.models.ModernTCN_Layer import')
    ns={'__name__':'_unmodified_modern_reference'};exec(compile(text,str(path),'exec'),ns)
    ref=ns['Model'](types.SimpleNamespace(enc_in=7,**m.config['model'])).eval();ref.load_state_dict(m.core.state_dict())
    truth=torch.randn(2,96,7);seen=torch.rand_like(truth)>.7;seen[:,0]=True;safe=torch.where(seen,truth,0.)
    assert torch.equal(m.core(safe,None,None,None,seen.float()),ref(safe,None,None,None,seen.float()))

def test_saits_loss_matches_author_ort_and_mit():
    torch.set_num_threads(2);torch.manual_seed(26)
    m=Initializer('SAITS','ETTh1',7,torch.device('cpu')).eval()
    truth=torch.randn(2,96,7);seen=torch.rand_like(truth)>.7;valid=torch.ones_like(seen)
    inp=dict(X=torch.where(seen,truth,0.),missing_mask=seen.float(),X_holdout=truth,indicating_mask=(~seen).float())
    result=m.core(inp,stage='val')
    expected=result['reconstruction_loss']+result['imputation_loss']
    torch.testing.assert_close(m.loss(truth,seen,valid),expected,atol=1e-6,rtol=1e-6)
