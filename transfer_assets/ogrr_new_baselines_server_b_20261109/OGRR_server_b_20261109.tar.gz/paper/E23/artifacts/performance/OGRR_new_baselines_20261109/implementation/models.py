"""Author networks, isolated imports, and native-missing-safe I/O adapters."""
import ast,configparser,importlib,sys,types
from pathlib import Path
import torch
from torch import nn

VENDOR=Path(__file__).resolve().parent/'vendor'

def package(name,path):
    obj=types.ModuleType(name);obj.__path__=[str(path)];sys.modules[name]=obj

def saits_config(dataset):
    name='PhysioNet2012_SAITS_best.ini' if dataset=='PhysioNet2012' else 'PhysioNet2012_SAITS_base.ini'
    path=VENDOR/'saits/configs'/name
    p=configparser.ConfigParser(interpolation=None);p.read(path)
    ints=['n_groups','n_group_inner_layers','d_model','d_inner','n_head','d_k','d_v']
    args={k:p.getint('model',k) for k in ints}
    args.update(dropout=p.getfloat('model','dropout'),input_with_mask=True,param_sharing_strategy='inner_group',MIT=True,diagonal_attention_mask=True)
    return dict(model=args,seed=26,batch_size=128,epochs=p.getint('training','epochs'),patience=p.getint('training','early_stop_patience'),lr=p.getfloat('training','lr'),weight_decay=0.,selection='mae',loss='ORT mean of three visible MAEs + MIT hidden MAE',source_config=str(path),selection_override='shared fixed full-validation MAE; evaluation once per epoch')

def modern_config(dataset):
    return dict(model=dict(task_name='imputation',seq_len=96,pred_len=0,stem_ratio=6,downsample_ratio=2,ffn_ratio=1,patch_size=1,patch_stride=1,num_blocks=[1],large_size=[71],small_size=[5],dims=[128]*4,dw_dims=[256]*4,small_kernel_merged=False,dropout=.1 if dataset=='Weather' else 0.,head_dropout=0.,use_multi_scale=False,revin=1,affine=0,subtract_last=0,freq='h',individual=0,kernel_size=25,decomposition=0),seed=2021,batch_size=16,epochs=100,patience=10,lr=.001,weight_decay=0.,selection='mse',loss='hidden MSE',source_config='ModernTCN-imputation/scripts/weather.sh' if dataset=='Weather' else 'ModernTCN-imputation/scripts/ETTh1.sh',unseen_dataset_rule='ETTh1 public imputation configuration; only input variable count changes',native_guard='two observed-count divisors clamp_min(1); identical on nonempty variables')

def timemixer_config(dataset):
    return dict(model=dict(task_name='imputation',n_steps=96,n_pred_steps=0,n_layers=2,d_model=64,d_ffn=64,n_heads=8,dropout=.1,top_k=3,n_kernels=6,channel_mixing=True,channel_independence=True,downsampling_layers=1,downsampling_window=2,downsampling_method='avg',use_future_temporal_feature=False,use_norm=False),seed=2021,batch_size=32,epochs=100,patience=10,lr=.001,weight_decay=0.,selection='mse',loss='hidden MSE',source='PyPOTS TimeMixer++ backbone, upstream commit 2271533587bab250163437ed39cfe13cefd8b80a',seed_source='no author recommended/best seed found; fixed protocol fallback 2021',configuration_note='predeclared shared configuration: L=2,K=3,M=1,Adam/L2/lr=.001 within reported paper choices; width64,FFN64,heads8,kernels6,dropout.1 fixed adaptation; batch32 memory adaptation versus paper512; not claimed as author dataset-optimal configuration; no extra window normalization')

def config_for(name,dataset):
    return {'SAITS':saits_config,'ModernTCN':modern_config,'TimeMixerPP':timemixer_config}[name](dataset)

class Initializer(nn.Module):
    def __init__(self,name,dataset,n_vars,device,config=None):
        super().__init__();self.name=name
        self.config=config or config_for(name,dataset)
        if name=='SAITS':
            root=VENDOR/'saits';package('modeling',root/'modeling')
            # Only the exact author MAE helper is exercised; avoid unrelated plotting/sklearn imports.
            path=root/'modeling/utils.py';tree=ast.parse(path.read_text())
            node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='masked_mae_cal')
            helper=types.ModuleType('modeling.utils');helper.torch=torch
            exec(compile(ast.Module(body=[node],type_ignores=[]),str(path),'exec'),helper.__dict__);sys.modules['modeling.utils']=helper
            cls=importlib.import_module('modeling.saits').SAITS
            self.core=cls(d_time=96,d_feature=n_vars,device=device,**self.config['model'])
        elif name=='ModernTCN':
            root=VENDOR/'moderntcn';prefix='_new_moderntcn';package(prefix,root)
            package(prefix+'.layers',root/'layers');package(prefix+'.models',root/'models')
            path=root/'models/ModernTCN.py';text=path.read_text()
            text=text.replace('from layers.RevIN import RevIN',f'from {prefix}.layers.RevIN import RevIN').replace('from models.ModernTCN_Layer import',f'from {prefix}.models.ModernTCN_Layer import')
            assert text.count('torch.sum(mask == 1, dim=1)')==2
            text=text.replace('torch.sum(mask == 1, dim=1)','torch.sum(mask == 1, dim=1).clamp_min(1)')
            module=types.ModuleType(prefix+'.models.ModernTCN');module.__file__=str(path);sys.modules[module.__name__]=module
            exec(compile(text,str(path),'exec'),module.__dict__)
            self.core=module.Model(types.SimpleNamespace(enc_in=n_vars,**self.config['model']))
        elif name=='TimeMixerPP':
            root=VENDOR/'timemixerpp_pypots';prefix='_new_timemixerpp';package(prefix,root)
            # Bypass unrelated PyPOTS top-level dependencies, retaining exact NN source.
            package(prefix+'.transformer',root/'transformer')
            cls=importlib.import_module(prefix+'.timemixerpp.backbone').BackboneTimeMixerPP
            self.core=cls(n_features=n_vars,n_pred_features=n_vars,**self.config['model'])
        else:raise ValueError(name)
        self.to(device)

    def reconstruction(self,safe,seen):
        safe=torch.where(seen,safe,0.)
        if self.name=='SAITS':
            _,outputs=self.core.impute({'X':safe,'missing_mask':seen.to(safe.dtype)})
            return outputs[-1],outputs
        out=self.core.imputation(safe,None) if self.name=='TimeMixerPP' else self.core(safe,None,None,None,seen.to(safe.dtype))
        return out,[out]

    def forward(self,values,seen,starts=None,**kwargs):
        safe=torch.where(seen,values,0.);out,_=self.reconstruction(safe,seen)
        return torch.where(seen,safe,out)

    def loss(self,truth,seen,valid):
        safe=torch.where(seen,truth,0.);out,stages=self.reconstruction(safe,seen)
        hidden=~seen&valid
        if self.name=='SAITS':
            visible=seen&valid
            ort=sum((x-truth).abs()[visible].mean() if visible.any() else x.sum()*0. for x in stages)/len(stages)
            mit=(out-truth).abs()[hidden].mean() if hidden.any() else out.sum()*0.
            return ort+mit
        return (out-truth).square()[hidden].mean() if hidden.any() else out.sum()*0.
