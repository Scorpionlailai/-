"""External dispatch only: does not mutate any frozen training implementation."""
import argparse,fcntl,hashlib,json,subprocess,sys,time,traceback
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'implementation'))
from run import write,summarize

def worker(server,slot,gpu):
    # Wait for the original all-dataset worker to finish its current case and
    # release this same lock. Never interrupt an in-flight training child.
    lock=(ROOT/f'worker_{slot}.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX)
    assignments=json.loads((ROOT/'server_assignment.json').read_text())
    a=set(assignments['server_a']['cases']);b=set(assignments['server_b']['cases'])
    assert not a&b and len(a|b)==72
    jobs=[key for key in assignments[server]['cases'] if server!='server_b' or key not in assignments.get('already_owned_by_server_a',[])][slot::2]
    manifest=json.loads((ROOT/'implementation_sha256.json').read_text())
    for relative,digest in manifest.items():assert hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()==digest,relative
    for key in jobs:
        if (ROOT/'STOP_ALL').exists():
            write(ROOT/f'worker_{slot}_status.json',dict(status='stopped_by_marker',server=server,gpu=gpu));return
        if (ROOT/'runs'/key/'complete.json').exists():continue
        write(ROOT/f'worker_{slot}_status.json',dict(status='running',server=server,case=key,gpu=gpu,time=time.time()))
        (ROOT/'logs').mkdir(exist_ok=True)
        args=[sys.executable,str(ROOT/'implementation/run.py'),'--case',key,'--device',f'cuda:{gpu}']
        with (ROOT/'logs'/(key.replace('/','__')+'.log')).open('a') as log:
            try:
                if not (ROOT/'smoke'/key/'complete.json').exists():subprocess.run(args+['--smoke'],stdout=log,stderr=subprocess.STDOUT,check=True)
                subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,check=True)
            except Exception:
                with (ROOT/'failures.jsonl').open('a') as f:f.write(json.dumps(dict(server=server,case=key,error=traceback.format_exc(),time=time.time()))+'\n')
        summarize()
    write(ROOT/f'worker_{slot}_status.json',dict(status='server_jobs_finished',server=server,gpu=gpu));summarize()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--server',choices=['server_a','server_b'],required=True);p.add_argument('--slot',type=int,choices=[0,1],required=True);p.add_argument('--gpu',type=int);p.add_argument('--wait-pid',type=int);a=p.parse_args()
    if a.wait_pid:
        write(ROOT/f'worker_{a.slot}_status.json',dict(status='waiting_for_inflight_case',server=a.server,gpu=a.slot if a.gpu is None else a.gpu,wait_pid=a.wait_pid))
        while Path(f'/proc/{a.wait_pid}').exists():
            # Orphaned completed children can briefly remain zombies.
            try:
                state=Path(f'/proc/{a.wait_pid}/stat').read_text().split(') ',1)[1].split()[0]
                if state=='Z':break
            except FileNotFoundError:break
            time.sleep(5)
    worker(a.server,a.slot,a.slot if a.gpu is None else a.gpu)
