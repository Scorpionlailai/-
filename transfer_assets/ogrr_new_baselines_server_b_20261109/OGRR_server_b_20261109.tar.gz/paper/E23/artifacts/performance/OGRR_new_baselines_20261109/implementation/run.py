"""Single-seed author-profile imputation, then frozen-backbone OGRR transfer."""
import argparse,collections,csv,fcntl,hashlib,json,os,statistics,sys,time,traceback
from pathlib import Path
import numpy as np
import torch

ROOT=Path(__file__).resolve().parents[1]
OLD=ROOT.parent/'OGRR_all_baselines_20261108'
sys.path.insert(0,str(OLD/'implementation_release_v2'))
import common
from common import sha,write,save,seed_all,sync,resource,state_hash,OGRR
sys.path.insert(0,str(Path(__file__).resolve().parent))
from models import Initializer,config_for

DATASETS=['ETTh1','Weather','Exchange-Rate','BeijingAirQuality','PAMAP2','PhysioNet2012']
SCENES=['sr015_bl8','sr010_bl8','sr020_bl8','sr010_bl16']
MODELS=['SAITS','ModernTCN','TimeMixerPP']

def input_case(dataset,scene):
    return next(c for c in json.loads((OLD/'cases.json').read_text()) if c['dataset']==dataset and c['scene']==scene and c['model']=='TimesNet')

def load_data(dataset,scene):
    c=input_case(dataset,scene)
    data=common.dataset(dataset,scene,**{k:c[k] for k in ['data_root','data_source_root','data_package'] if k in c})
    alignment=common.verify_original_masks(data,c)
    return data,c,alignment

def bind(case,data):
    files={str(p):sha(p) for p in sorted((ROOT/'implementation').rglob('*')) if p.is_file() and p.suffix in ['.py','.ini']}
    for p in [data.assets/'manifest.json',*data.assets.glob('*.npz')]:files[str(p)]=sha(p)
    c=input_case(case['dataset'],case['scene'])
    if c.get('mask_root'):
        for p in Path(c['mask_root']).glob('*.npz'):files[str(p)]=sha(p)
    # Preserve the exact shared loader and OGRR implementation lineage as well.
    for folder in [OLD/'implementation_release_v2',common.DONOR]:
        for p in folder.rglob('*.py'):files[str(p)]=sha(p)
    return dict(case=case,files=files,dataset_manifest=data.manifest,environment=dict(torch=torch.__version__,cuda=torch.version.cuda,numpy=np.__version__))

def aggregate(sums):
    assert sums[2]>0,'no hidden native-valid evaluation coordinates'
    return dict(mse=sums[0]/sums[2],mae=sums[1]/sums[2],coordinates=sums[2])

@torch.no_grad()
def evaluate(model,head,data,split,device,seed=None,limit=None,cache=None):
    model.eval()
    if head is not None:head.eval()
    totals={'raw':[0.,0.,0],'ogrr':[0.,0.,0]};blocks=[];windows=0
    source=cache if cache is not None else data.batches(split,128,mask_seed=seed,max_batches=limit)
    for item in source:
        if cache is None:
            truth,seen,starts=item;truth=truth.to(device);seen=seen.to(device)
            coarse=model(torch.where(seen,truth,0.),seen,starts)
            if split=='validation':blocks.append((coarse.cpu(),truth.cpu(),seen.cpu(),starts))
        else:
            coarse,truth,seen,starts=item;coarse=coarse.to(device);truth=truth.to(device);seen=seen.to(device)
        valid=torch.from_numpy(data.valid_for(starts)).to(device);safe=torch.where(seen,truth,0.)
        outputs={'raw':coarse}
        if head is not None:outputs['ogrr']=head(coarse,safe,seen)
        for name,pred in outputs.items():
            assert torch.isfinite(pred).all(),name
            assert torch.equal(pred[seen],safe[seen]),'visible observations changed'
            err=(pred-truth).double()[~seen&valid]
            vals=[float(err.square().sum()),float(err.abs().sum()),err.numel()]
            totals[name]=[a+b for a,b in zip(totals[name],vals)]
        windows+=len(starts)
    if limit is None:assert windows==len(data.starts[split])
    result={'raw':aggregate(totals['raw']),'windows':windows}
    if head is not None:result['ogrr']=aggregate(totals['ogrr'])
    return result,blocks

def preflight(model,data,device,out):
    model.eval();truth,seen,starts=next(data.batches('validation',4,max_batches=1))
    truth=truth.to(device);seen=seen.to(device);valid=torch.from_numpy(data.valid_for(starts)).to(device)
    # Explicitly exercise a completely unobserved variable, frequent in block/native missingness.
    seen[:, :,0]=False
    safe=torch.where(seen,truth,0.);pred=model(safe,seen,starts)
    assert torch.isfinite(pred).all();assert torch.equal(pred[seen],truth[seen])
    assert torch.equal(pred,model(torch.where(seen,safe,torch.full_like(safe,float('nan'))),seen,starts))
    before=state_hash(model);model.zero_grad(set_to_none=True)
    loss=model.loss(truth,seen,valid);assert torch.isfinite(loss);loss.backward()
    assert all(torch.isfinite(p.grad).all() for p in model.parameters() if p.grad is not None)
    assert any(p.grad is not None and bool((p.grad!=0).any()) for p in model.parameters())
    model.zero_grad(set_to_none=True);assert state_hash(model)==before
    clone=Initializer(model.name,out.parts[-3],data.n_vars,device,model.config)
    clone.load_state_dict(model.state_dict(),strict=True);clone.eval()
    assert torch.equal(pred,clone(safe,seen,starts));del clone
    write(out/'preflight.json',dict(status='passed',hidden_truth_invariant=True,all_missing_variable_finite=True,visible_preservation=True,finite_gradient=True,nonzero_gradient=True,export_exact=True))

def train_coarse(model,data,device,out,binding,smoke=False):
    cfg=model.config;epochs=2 if smoke else cfg['epochs'];limit=1 if smoke else None
    if (out/'coarse_complete.json').exists():
        saved=torch.load(out/'coarse_selected.pt',map_location=device,weights_only=False)
        assert saved['binding']==binding;model.load_state_dict(saved['model']);return
    opt=torch.optim.Adam(model.parameters(),lr=cfg['lr'],weight_decay=cfg['weight_decay'])
    seed_all(cfg['seed']);first=1;best=float('inf');stale=0;elapsed=0.;train_seconds=0.;best_epoch=0
    if (out/'coarse_latest.pt').exists():
        p=torch.load(out/'coarse_latest.pt',map_location=device,weights_only=False);assert p['binding']==binding
        model.load_state_dict(p['model']);opt.load_state_dict(p['optimizer']);first=p['epoch']+1
        best=p['best'];stale=p['stale'];elapsed=p['elapsed'];train_seconds=p['train_seconds'];best_epoch=p['best_epoch']
        torch.set_rng_state(p['rng_cpu'].cpu());np.random.set_state(p['rng_numpy'])
        torch.cuda.set_rng_state(p['rng_cuda'].cpu(),device)
    began=time.perf_counter()
    for epoch in range(first,epochs+1):
        model.train();t=time.perf_counter();sum_loss=0.;updates=0
        for truth,seen,starts in data.batches('train',cfg['batch_size'],epoch=epoch-1,seed=2023,max_batches=limit):
            truth=truth.to(device);seen=seen.to(device);valid=torch.from_numpy(data.valid_for(starts)).to(device)
            opt.zero_grad(set_to_none=True);loss=model.loss(truth,seen,valid)
            assert torch.isfinite(loss);loss.backward();opt.step();sum_loss+=float(loss.detach());updates+=1
        assert updates>0;sync(device);train_seconds+=time.perf_counter()-t
        v,_=evaluate(model,None,data,'validation',device,limit=limit)
        value=v['raw'][cfg['selection']]
        if value<best:
            best=value;stale=0;best_epoch=epoch
            save(out/'coarse_selected.pt',dict(model=model.state_dict(),epoch=epoch,validation=v,binding=binding))
        else:stale+=1
        if model.name=='ModernTCN':
            lr=cfg['lr'] if epoch<3 else cfg['lr']*.9**(epoch-3)
            for g in opt.param_groups:g['lr']=lr
        row=dict(stage='coarse',epoch=epoch,epochs_max=epochs,validation=v,best_epoch=best_epoch,stale=stale,updates=updates,loss=sum_loss/updates,epoch_seconds=time.perf_counter()-t,elapsed_seconds=elapsed+time.perf_counter()-began,resources=resource(device))
        write(out/'coarse_epochs'/f'{epoch:04}.json',row);write(out/'status.json',row)
        save(out/'coarse_latest.pt',dict(model=model.state_dict(),optimizer=opt.state_dict(),epoch=epoch,best=best,best_epoch=best_epoch,stale=stale,elapsed=row['elapsed_seconds'],train_seconds=train_seconds,binding=binding,rng_cpu=torch.get_rng_state(),rng_cuda=torch.cuda.get_rng_state(device),rng_numpy=np.random.get_state()))
        print(json.dumps(dict(case=binding['case']['key'],**{k:row[k] for k in ['stage','epoch','best_epoch','epoch_seconds']})),flush=True)
        if stale>=cfg['patience']:break
    saved=torch.load(out/'coarse_selected.pt',map_location=device,weights_only=False);model.load_state_dict(saved['model'])
    write(out/'coarse_complete.json',dict(selected_epoch=saved['epoch'],trained_epochs=epoch,selection=cfg['selection'],seconds=elapsed+time.perf_counter()-began,train_seconds=train_seconds,resources=resource(device),checkpoint_sha256=sha(out/'coarse_selected.pt')))

def train_head(model,head,data,device,out,binding,smoke=False):
    epochs=2 if smoke else 100;limit=1 if smoke else None
    model.requires_grad_(False).eval();digest=state_hash(model)
    if (out/'ogrr_complete.json').exists():
        p=torch.load(out/'ogrr_selected.pt',map_location=device,weights_only=False);assert p['binding']==binding;head.load_state_dict(p['head']);return
    _,cache=evaluate(model,head,data,'validation',device,limit=limit)
    coarse,truth,seen,_=cache[0]
    with torch.no_grad():torch.testing.assert_close(head(coarse.to(device),truth.to(device),seen.to(device)),coarse.to(device),atol=3e-6,rtol=1e-6)
    opt=torch.optim.Adam(head.parameters(),lr=.001);seed_all(2023)
    first=1;best=float('inf');elapsed=0.;train_seconds=0.;best_epoch=0
    if (out/'ogrr_latest.pt').exists():
        p=torch.load(out/'ogrr_latest.pt',map_location=device,weights_only=False);assert p['binding']==binding
        head.load_state_dict(p['head']);opt.load_state_dict(p['optimizer']);first=p['epoch']+1;best=p['best'];best_epoch=p['best_epoch'];elapsed=p['elapsed'];train_seconds=p['train_seconds']
        torch.set_rng_state(p['rng_cpu'].cpu());torch.cuda.set_rng_state(p['rng_cuda'].cpu(),device);np.random.set_state(p['rng_numpy'])
    began=time.perf_counter()
    for epoch in range(first,epochs+1):
        head.train();t=time.perf_counter();updates=0
        for truth,seen,starts in data.batches('train',128,epoch=epoch-1,seed=2023,max_batches=limit):
            truth=truth.to(device);seen=seen.to(device);valid=torch.from_numpy(data.valid_for(starts)).to(device)
            safe=torch.where(seen,truth,0.)
            with torch.no_grad():coarse=model(safe,seen,starts)
            opt.zero_grad(set_to_none=True);pred=head(coarse,safe,seen);err=(pred-truth).abs();hidden=~seen&valid;tail=hidden[:,-32:]
            loss=(err[hidden].mean() if hidden.any() else pred.sum()*0.)+.25*(err[:,-32:][tail].mean() if tail.any() else pred.sum()*0.)
            assert torch.isfinite(loss);loss.backward();opt.step();updates+=1
        sync(device);train_seconds+=time.perf_counter()-t
        assert state_hash(model)==digest and all(p.grad is None for p in model.parameters())
        v,_=evaluate(model,head,data,'validation',device,limit=limit,cache=cache)
        if v['ogrr']['mae']<best:
            best=v['ogrr']['mae'];best_epoch=epoch
            save(out/'ogrr_selected.pt',dict(head=head.state_dict(),epoch=epoch,validation=v,binding=binding))
        row=dict(stage='ogrr',epoch=epoch,validation=v,best_epoch=best_epoch,updates=updates,epoch_seconds=time.perf_counter()-t,elapsed_seconds=elapsed+time.perf_counter()-began,backbone_frozen_verified=True,resources=resource(device))
        write(out/'ogrr_epochs'/f'{epoch:03}.json',row);write(out/'status.json',row)
        save(out/'ogrr_latest.pt',dict(head=head.state_dict(),optimizer=opt.state_dict(),epoch=epoch,best=best,best_epoch=best_epoch,elapsed=row['elapsed_seconds'],train_seconds=train_seconds,binding=binding,rng_cpu=torch.get_rng_state(),rng_cuda=torch.cuda.get_rng_state(device),rng_numpy=np.random.get_state()))
        print(json.dumps(dict(case=binding['case']['key'],stage='ogrr',epoch=epoch,best_epoch=best_epoch,epoch_seconds=row['epoch_seconds'])),flush=True)
    p=torch.load(out/'ogrr_selected.pt',map_location=device,weights_only=False);head.load_state_dict(p['head'])
    write(out/'ogrr_complete.json',dict(selected_epoch=p['epoch'],epochs=epochs,seconds=elapsed+time.perf_counter()-began,train_seconds=train_seconds,resources=resource(device),backbone_before=digest,backbone_after=state_hash(model),checkpoint_sha256=sha(out/'ogrr_selected.pt')))

def run(key,device,smoke=False):
    started=time.perf_counter();dataset,scene,name=key.split('/');cfg=config_for(name,dataset)
    torch.set_num_threads(4);device=torch.device(device);torch.cuda.set_device(device)
    out=ROOT/('smoke' if smoke else 'runs')/key;out.mkdir(parents=True,exist_ok=True)
    lock=(out/'run.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    data,original,alignment=load_data(dataset,scene)
    write(out/'original_masks.json',alignment or dict(status='shared canonical data mask bank',manifest=data.manifest))
    case=dict(key=key,dataset=dataset,scene=scene,model=name,config=cfg,ogrr_seed=2023,ogrr_epochs=2 if smoke else 100,ogrr_loss='full96 MAE + .25 last32 MAE',ogrr_selection='fixed full96 validation MAE',training_mask_seed=2023,smoke=smoke)
    binding=bind(case,data)
    if (out/'binding.json').exists():assert json.loads((out/'binding.json').read_text())==binding,'source/data/config changed since run'
    write(out/'binding.json',binding)
    if (out/'complete.json').exists():return
    seed_all(cfg['seed']);model=Initializer(name,dataset,data.n_vars,device,cfg)
    preflight(model,data,device,out);seed_all(cfg['seed']);model=Initializer(name,dataset,data.n_vars,device,cfg)
    torch.cuda.reset_peak_memory_stats(device)
    train_coarse(model,data,device,out,binding,smoke)
    model.zero_grad(set_to_none=True);model.requires_grad_(False).eval()
    head=OGRR(data).to(device);torch.cuda.reset_peak_memory_stats(device)
    train_head(model,head,data,device,out,binding,smoke)
    # Verify the selected head exports exactly, using the frozen selected backbone.
    restored=OGRR(data).to(device).eval();restored.load_state_dict(head.state_dict(),strict=True);head.eval()
    truth,seen,starts=next(data.batches('validation',4,max_batches=1));truth=truth.to(device);seen=seen.to(device)
    safe=torch.where(seen,truth,0.)
    with torch.no_grad():
        coarse=model(safe,seen,starts)
        assert torch.equal(head(coarse,safe,seen),restored(coarse,safe,seen))
        assert torch.equal(head(coarse,safe,seen),head(coarse,torch.where(seen,safe,torch.full_like(safe,float('nan'))),seen))
    del restored
    write(out/'selected_export_check.json',dict(coarse_export_exact=True,ogrr_export_exact=True,ogrr_hidden_truth_invariant=True,coarse_sha256=sha(out/'coarse_selected.pt'),ogrr_sha256=sha(out/'ogrr_selected.pt')))
    if smoke:
        write(out/'complete.json',dict(status='smoke_passed',frozen=True,export_exact=True));return
    write(out/'status.json',dict(stage='testing',completed_masks=0,total_masks=20));rows=[]
    for seed in data.test_seeds:
        p=out/'test_masks'/f'{seed}.json'
        if p.exists():row=json.loads(p.read_text())
        else:
            row,_=evaluate(model,head,data,'test',device,seed=seed);row['mask_seed']=seed;write(p,row)
        rows.append(row);write(out/'status.json',dict(stage='testing',completed_masks=len(rows),total_masks=20))
    assert len(rows)==20
    summary=dict(case=case,test_masks=20,per_mask=rows,process_seconds=time.perf_counter()-started,coarse=json.loads((out/'coarse_complete.json').read_text()),head=json.loads((out/'ogrr_complete.json').read_text()),backbone_parameters=sum(p.numel() for p in model.parameters()),ogrr_parameters=sum(p.numel() for p in head.parameters()),gpu=torch.cuda.get_device_name(device))
    for stage in ['raw','ogrr']:
        summary[stage]={}
        for metric in ['mse','mae']:
            values=[x[stage][metric] for x in rows];summary[stage][metric]=float(np.mean(values));summary[stage][metric+'_mask_std_ddof1']=float(np.std(values,ddof=1))
    summary['paired']={m:dict(relative_reduction_pct=100*(summary['raw'][m]-summary['ogrr'][m])/summary['raw'][m],positive_masks=sum(x['raw'][m]>x['ogrr'][m] for x in rows)) for m in ['mse','mae']}
    truth,seen,starts=next(data.batches('validation',128,max_batches=1));truth=truth.to(device);seen=seen.to(device);safe=torch.where(seen,truth,0.)
    timings={'backbone':[],'backbone_plus_ogrr':[]}
    model.eval();head.eval()
    with torch.no_grad():
        for stage in timings:
            for i in range(30):
                sync(device);t=time.perf_counter();coarse=model(safe,seen,starts)
                if stage=='backbone_plus_ogrr':head(coarse,safe,seen)
                sync(device)
                if i>=5:timings[stage].append((time.perf_counter()-t)*1000)
    summary['inference_p50_ms']={k:statistics.median(v) for k,v in timings.items()};summary['latency_batch_size']=len(truth)
    write(out/'results.json',summary);write(out/'complete.json',dict(status='complete',results_sha256=sha(out/'results.json'),coarse_checkpoint_sha256=sha(out/'coarse_selected.pt'),ogrr_checkpoint_sha256=sha(out/'ogrr_selected.pt')))
    write(out/'status.json',dict(stage='complete',raw=summary['raw'],ogrr=summary['ogrr']))
    print('COMPLETE',key,summary['raw'],summary['ogrr'],flush=True)

def summarize():
    lock=(ROOT/'summary.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX)
    rows=[];statuses=[]
    for dataset in DATASETS:
        for scene in SCENES:
            for name in MODELS:
                out=ROOT/'runs'/dataset/scene/name
                status=json.loads((out/'status.json').read_text()) if (out/'status.json').exists() else {'stage':'queued'}
                statuses.append(dict(dataset=dataset,scene=scene,model=name,**status))
                if not (out/'complete.json').exists():continue
                d=json.loads((out/'results.json').read_text())
                row=dict(dataset=dataset,scene=scene,model=name,backbone_seed=d['case']['config']['seed'],head_seed=2023,test_masks=20,**{f'{s}_{m}':d[s][m] for s in ['raw','ogrr'] for m in ['mse','mae']},**{f'{m}_reduction_pct':d['paired'][m]['relative_reduction_pct'] for m in ['mse','mae']},backbone_seconds=d['coarse']['seconds'],ogrr_seconds=d['head']['seconds'],backbone_peak_allocated_gib=d['coarse']['resources']['max_allocated_gib'],ogrr_peak_allocated_gib=d['head']['resources']['max_allocated_gib'],result=str(out/'results.json'))
                rows.append(row)
    target=ROOT/'comparison.csv';tmp=target.with_suffix('.csv.tmp')
    if rows:
        with tmp.open('w') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
        tmp.replace(target)
    write(ROOT/'progress.json',dict(total_cases=72,completed=len(rows),cases=statuses))

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--case');p.add_argument('--device',default='cuda:0');p.add_argument('--smoke',action='store_true');p.add_argument('--summarize',action='store_true');a=p.parse_args()
    if a.summarize:summarize()
    else:
        try:run(a.case,a.device,a.smoke)
        except BaseException:
            out=ROOT/('smoke' if a.smoke else 'runs')/a.case;write(out/'status.json',dict(stage='failed',traceback=traceback.format_exc()));raise
