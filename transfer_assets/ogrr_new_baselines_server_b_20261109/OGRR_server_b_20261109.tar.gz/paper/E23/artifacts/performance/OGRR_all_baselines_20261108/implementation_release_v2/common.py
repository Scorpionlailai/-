"""Locked R3 OGRR and data APIs; no changes to the frozen archive."""
from pathlib import Path
import os,sys,json,hashlib,random,fcntl,types,importlib
import numpy as np
import torch
ROOT=Path(__file__).resolve().parents[1]
DONOR=Path('/home/xyw/paper/E23/artifacts/performance/Beijing_sr020_T1_R3_calibration_20261101/implementation')
sys.path.insert(0,str(DONOR))
import bootstrap
from data import load_data
from r2_variants import make_calibrator
from malr.data.normalization import masked_window_normalize,fit_train_variable_stats
from types import SimpleNamespace

def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def write(path,obj):
 p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n');t.replace(p)
def save(path,obj):
 p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);t=p.with_suffix(p.suffix+'.tmp');torch.save(obj,t);t.replace(p)
def seed_all(seed):
 random.seed(seed);np.random.seed(seed);torch.manual_seed(seed)
 if torch.cuda.is_available():torch.cuda.manual_seed_all(seed)
def state_hash(m):
 h=hashlib.sha256()
 for k,v in sorted(m.state_dict().items()):h.update(k.encode());h.update(v.detach().cpu().contiguous().numpy().tobytes())
 return h.hexdigest()
def sync(device):
 if device.type=='cuda':torch.cuda.synchronize(device)
def resource(device):
 return dict(gpu=torch.cuda.get_device_name(device) if device.type=='cuda' else 'CPU',torch=torch.__version__,cuda=torch.version.cuda,max_allocated_gib=torch.cuda.max_memory_allocated(device)/2**30 if device.type=='cuda' else 0.,max_reserved_gib=torch.cuda.max_memory_reserved(device)/2**30 if device.type=='cuda' else 0.)
def dataset(dataset,scene,data_root=None,data_source_root=None,data_package=None):
 root=Path(data_root) if data_root else (Path('/home/xyw/r3_release_20261030') if dataset=='PhysioNet2012' else Path('/home/xyw/paper'))
 os.environ['R2_DATA_ROOT']=str(root)
 folder=ROOT/'assets'/dataset/scene;folder.mkdir(parents=True,exist_ok=True)
 with (folder/'preparation.lock').open('a') as f:
  fcntl.flock(f,fcntl.LOCK_EX)
  if data_source_root and dataset in ['BeijingAirQuality','PAMAP2','PhysioNet2012']:
   package='_ogrr_original_data_'+hashlib.sha256(str(data_source_root).encode()).hexdigest()[:12];pkg=types.ModuleType(package)
   pkg.__path__=[str(Path(data_source_root)/'E24/integrations'/data_package)];sys.modules[package]=pkg
   module=importlib.import_module(package+'.data');module.ROOT=root
   data=module.SharedData(dataset,scene,ROOT/'assets_original')
   if not hasattr(data,'valid_for'):data.valid_for=lambda starts,offset=0:np.ones((len(starts),96,data.n_vars),dtype=bool)
   return data
  return load_data(dataset,scene,ROOT/'assets')

def verify_original_masks(data,case):
 if not case.get('mask_root'):return None
 bank=Path(case['mask_root']);original=json.loads((bank/'manifest.json').read_text())
 assert original['test_seeds']==data.test_seeds
 assert original['windows']==data.manifest['windows'],'original window support changed'
 assert original['generator_sha256']==data.manifest['generator_sha256'],'original mask generator changed'
 records=[]
 for (split,seed),actual in data.masks.items():
  path=bank/f'{split}_{seed}.npz'
  with np.load(path,allow_pickle=False) as stored:expected=stored['observed' if 'observed' in stored.files else 'observed_mask']
  assert np.array_equal(actual,expected),('original mask differs',case['key'],split,seed)
  records.append(dict(split=split,seed=seed,original_file_sha256=sha(path),content_sha256=hashlib.sha256(actual.tobytes()).hexdigest()))
 assert len(records)==21
 for key in ['scaler','source_sha256','prepared_manifest_sha256','native_observation_sha256']:
  if key in original:assert original[key]==data.manifest[key],('data definition changed',key)
 return dict(status='all_21_original_masks_identical',files=records)

def interpolate(values,observed):
 """Within-window same-variable linear/one-sided reference; no future window."""
 safe=torch.where(observed,values,0.)
 t=torch.arange(values.shape[1],device=values.device)[None,:,None]
 left=torch.cummax(torch.where(observed,t,-1),1).values
 right=torch.cummin(torch.where(observed,t,values.shape[1]).flip(1),1).values.flip(1)
 lv=safe.gather(1,left.clamp_min(0));rv=safe.gather(1,right.clamp_max(values.shape[1]-1))
 both=(left>=0)&(right<values.shape[1])&(right>left)
 linear=lv+(rv-lv)*(t-left)/(right-left).clamp_min(1)
 filled=torch.where(both,linear,torch.where(left>=0,lv,torch.where(right<values.shape[1],rv,0.)))
 return torch.where(observed,safe,filled)

class OGRR(torch.nn.Module):
 def __init__(self,data,seed=2023):
  super().__init__();self.data=data
  self.refiner=make_calibrator(data.n_vars,'H_GLOBAL',seed).global_dense_refiner
  if not hasattr(data,'_reference_fallback'):
   data._reference_fallback=fit_train_variable_stats(torch.from_numpy(data.values[:data.bounds.train.end]),eps=0.)
 def forward(self,coarse,values,observed):
  safe=torch.where(observed,values,0.)
  norm=masked_window_normalize(safe,observed,self.data._reference_fallback,eps=1e-5)
  local=(coarse.detach()-norm.mean[:,None])/norm.std[:,None]
  explicit=SimpleNamespace(sequence_validity=torch.ones_like(observed),sequence_observed=observed,observed_sequence=norm.student)
  refined=self.refiner(local,explicit,norm.mean,norm.std)
  active=(~observed)&observed.flatten(1).any(-1)[:,None,None]
  result=torch.where(active,refined,local)*norm.std[:,None]+norm.mean[:,None]
  return torch.where(observed,safe,result)
