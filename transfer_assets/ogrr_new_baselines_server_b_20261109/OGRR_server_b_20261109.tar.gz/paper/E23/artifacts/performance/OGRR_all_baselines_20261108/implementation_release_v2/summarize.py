from pathlib import Path
import json,csv
from common import ROOT,write
from provenance import verify_finished

def summarize():
 cases=json.loads((ROOT/'cases.json').read_text());rows=[];status=[]
 for c in cases:
  out=ROOT/'runs'/c['key'];res=out/'results.json';st=json.loads((out/'status.json').read_text()) if (out/'status.json').exists() else {'status':c['status']}
  status.append(dict(dataset=c['dataset'],scene=c['scene'],model=c['model'],**st))
  if not res.exists():continue
  try:
   if not verify_finished(c,out):continue
  except Exception as e:
   status[-1]['status']='stale_provenance';status[-1]['error']=str(e);continue
  d=json.loads(res.read_text());row=dict(dataset=c['dataset'],scene=c['scene'],model=c['model'],head_seed=2023,status='reused' if d.get('reused') else 'complete',test_masks=d['test_masks'],raw_mse=d['raw']['mse'],raw_mae=d['raw']['mae'],ogrr_mse=d['ogrr']['mse'],ogrr_mae=d['ogrr']['mae'],mse_reduction_pct=100*(d['raw']['mse']-d['ogrr']['mse'])/d['raw']['mse'],mae_reduction_pct=100*(d['raw']['mae']-d['ogrr']['mae'])/d['raw']['mae'],ogrr_added_latency_p50_ms=d.get('ogrr_added_latency_p50_ms'),result=str(res))
  row['mse_improved']=row['ogrr_mse']<row['raw_mse'];row['mae_improved']=row['ogrr_mae']<row['raw_mae'];rows.append(row)
  training=json.loads((out/'training_complete.json').read_text()) if (out/'training_complete.json').exists() else {}
  row.update(ogrr_training_seconds=training.get('train_seconds'),training_and_validation_seconds=training.get('seconds'),complete_process_seconds=d.get('process_seconds'),peak_allocated_gib=d.get('resources',{}).get('max_allocated_gib'),peak_reserved_gib=d.get('resources',{}).get('max_reserved_gib'),ogrr_parameters=d.get('ogrr_parameters'),backbone_parameters=d.get('backbone_parameters'))
 fields=list(rows[0]) if rows else ['dataset','scene','model','status','raw_mse','raw_mae','ogrr_mse','ogrr_mae']
 with (ROOT/'comparison.csv').open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)
 report=dict(total_cases=len(cases),completed=len(rows),mse_improved=sum(x['mse_improved'] for x in rows),mae_improved=sum(x['mae_improved'] for x in rows),pending_original_assets=sum('missing' in c['status'] for c in cases),cases=status)
 write(ROOT/'progress.json',report);print({k:v for k,v in report.items() if k!='cases'})
if __name__=='__main__':summarize()
