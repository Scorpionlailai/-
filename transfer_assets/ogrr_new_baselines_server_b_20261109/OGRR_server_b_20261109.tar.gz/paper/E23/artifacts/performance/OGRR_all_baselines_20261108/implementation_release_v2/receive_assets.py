"""Materialize hash-addressed original source without modifying the live projects."""
from pathlib import Path
import hashlib,json,shutil
from common import ROOT,sha,write

def receive():
 index=json.loads((ROOT/'incoming/asset_index.json').read_text())
 registry=json.loads((ROOT/'received_assets.json').read_text()) if (ROOT/'received_assets.json').exists() else {};audit=[]
 for row in index['rows']:
  relative=row.get('checkpoint_archive_path')
  if not relative or not (ROOT/'received'/relative).is_file():continue
  key='/'.join(row[k] for k in ['dataset','scene','model'])
  checkpoint=ROOT/'received'/relative
  assert sha(checkpoint)==row['original_checkpoint_sha256']
  # Independent source trees retain distinct sealed versions of identically named files.
  root=ROOT/'original_sources'/row['dataset']/row['scene']/row['model'];missing=[];expected={}
  for path,digest in row['source_seal']['files'].items():
   source=ROOT/'received/source_by_sha256'/digest/Path(path).name
   if not source.exists():missing.append(dict(path=path,sha256=digest));continue
   assert sha(source)==digest
   target=root/path;target.parent.mkdir(parents=True,exist_ok=True)
   if not target.exists():shutil.copyfile(source,target)
   assert sha(target)==digest;expected[path]=digest
  plan_path=ROOT/'received'/row['configuration'];plan=json.loads(plan_path.read_text())
  selection_path=ROOT/'received'/row['selection_record']
  mask_root=ROOT/'received'/Path(row['mask_directory']).relative_to('/home/xyw/paper')
  assert len(list(mask_root.glob('test_*.npz')))==20 and (mask_root/'validation_2021.npz').is_file()
  record_path=ROOT/'original_asset_rows'/row['dataset']/row['scene']/(row['model']+'.json');write(record_path,row)
  package={'ETTh1':'repair_baselines','Weather':'repair_baselines','BeijingAirQuality':'beijing_baselines','PAMAP2':'pamap2_baselines','PhysioNet2012':'physionet_baselines'}[row['dataset']]
  registry[key]=dict(registry.get(key,{}),checkpoint=str(checkpoint),checkpoint_sha256=sha(checkpoint),source_root=str(root),source_expected=expected,
   config_path=str(plan_path),selection_path=str(selection_path),original_result_path=str(ROOT/'received'/row['original_result_source']),
   asset_row_path=str(record_path),mask_root=str(mask_root),original_adapter=package,
   profile=dict(training=row['original_profile'],model=plan['model_config']),backbone_seed=row['training_seed'])
  audit.append(dict(key=key,checkpoint_sha256=sha(checkpoint),original_source_files=len(expected),missing_source_files=missing,mask_files=21))
 write(ROOT/'received_assets.json',registry);write(ROOT/'received_adapter_audit.json',audit)
 print(dict(original_checkpoints=len(registry),source_roots=len(audit)))

if __name__=='__main__':receive()
