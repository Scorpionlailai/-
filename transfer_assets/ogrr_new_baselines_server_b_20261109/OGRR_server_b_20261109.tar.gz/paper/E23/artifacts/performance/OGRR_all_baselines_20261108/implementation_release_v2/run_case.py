"""Train only OGRR on a frozen initializer; validation selection then paired tests."""
import argparse,fcntl,json,time,hashlib,traceback,statistics
from pathlib import Path
import numpy as np
import torch
from common import ROOT,DONOR,sha,write,save,seed_all,state_hash,sync,resource,dataset,OGRR,verify_original_masks
from backbones import build
from provenance import make_binding,verify_finished

def errors(pred,truth,seen,valid):
 e=(pred-truth).double()[~seen&valid]
 return [float(e.square().sum()),float(e.abs().sum()),e.numel()]
def metric(t):
 return dict(mse=t[0]/t[2] if t[2] else None,mae=t[1]/t[2] if t[2] else None,coordinates=t[2])
def evaluate(frozen,head,data,split,device,mask_seed=None,cached=None,max_batches=None):
 sums={'raw':[0.,0.,0],'ogrr':[0.,0.,0]};blocks=[];count=0
 source=cached if cached is not None else data.batches(split,128,mask_seed=mask_seed,max_batches=max_batches)
 head.eval();frozen.eval()
 with torch.no_grad():
  for item in source:
   if cached is None:
    truth,seen,starts=item;truth=truth.to(device);seen=seen.to(device)
    safe=torch.where(seen,truth,0.);coarse=frozen(safe,seen,starts,mask_seed=mask_seed)
    if split=='validation':blocks.append((coarse.cpu(),truth.cpu(),seen.cpu(),starts))
   else:
    coarse,truth,seen,starts=item;coarse=coarse.to(device);truth=truth.to(device);seen=seen.to(device);safe=torch.where(seen,truth,0.)
   final=head(coarse,safe,seen)
   assert torch.isfinite(coarse).all() and torch.isfinite(final).all()
   assert torch.equal(coarse[seen],safe[seen]) and torch.equal(final[seen],safe[seen])
   valid=torch.from_numpy(data.valid_for(starts)).to(device)
   for k,p in [('raw',coarse),('ogrr',final)]:
    row=errors(p,truth,seen,valid);sums[k]=[a+b for a,b in zip(sums[k],row)]
   count+=len(starts)
 if max_batches is None:assert count==len(data.starts[split]),(count,len(data.starts[split]))
 return dict(windows=count,raw=metric(sums['raw']),ogrr=metric(sums['ogrr'])),blocks

def run(key,device,smoke=False):
 torch.set_num_threads(4);seed_all(2023);device=torch.device(device)
 if device.type=='cuda':torch.cuda.set_device(device)
 cases=json.loads((ROOT/'cases.json').read_text());case=next(c for c in cases if c['key']==key)
 out=ROOT/('smoke' if smoke else 'runs')/key;out.mkdir(parents=True,exist_ok=True)
 lock=(out/'case.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 if verify_finished(case,out,smoke):return
 if case['status']=='missing_original_weight':raise FileNotFoundError(case['key'])
 process=time.perf_counter();data=dataset(case['dataset'],case['scene'],data_root=case.get('data_root'),data_source_root=case.get('data_source_root'),data_package=case.get('data_package'))
 alignment=verify_original_masks(data,case)
 if alignment:write(out/'original_mask_alignment.json',alignment)
 if 'checkpoint' in case:assert sha(case['checkpoint'])==case['checkpoint_sha256']
 frozen=build(case,data,device);head=OGRR(data).to(device)
 bound=make_binding(case,data,smoke)
 if (out/'binding.json').exists():assert json.loads((out/'binding.json').read_text())==bound,'resume source binding changed'
 write(out/'binding.json',bound)
 frozen_digest=state_hash(frozen);initial_head=state_hash(head)
 if device.type=='cuda':torch.cuda.reset_peak_memory_stats(device)
 validation,cache=evaluate(frozen,head,data,'validation',device,max_batches=1 if smoke else None)
 expected=None
 if 'checkpoint' in case:
  payload=torch.load(case['checkpoint'],map_location='cpu',weights_only=False);v=case.get('expected_validation',payload.get('validation',{}))
  if 'mse' in v:expected={k:v[k] for k in ['mse','mae']}
  elif 'full96' in v:expected={k:v['full96'][k] for k in ['mse','mae']}
 if not smoke and expected:
  for m in ['mse','mae']:
   assert abs(validation['raw'][m]-expected[m])<5e-6,('original validation replay mismatch',m,validation['raw'],expected)
 with torch.no_grad():
  b,t,m,st=cache[0];b=b.to(device);t=t.to(device);m=m.to(device);safe=torch.where(m,t,0.)
  initial=head(b,safe,m);torch.testing.assert_close(initial,b,atol=3e-6,rtol=1e-6)
  changed=torch.where(m,safe,torch.full_like(safe,float('nan')))
  assert torch.equal(initial,head(b,changed,m))
 write(out/'preflight.json',dict(status='passed',initialization_identity=True,hidden_input_invariant=True,visible_preservation=True,raw_validation=validation['raw'],archived_validation=expected,head_initial_hash=initial_head,head_parameters=sum(p.numel() for p in head.parameters()),original_backbone_hash=frozen_digest,validation_cached=True))
 opt=torch.optim.Adam(head.parameters(),lr=.001,weight_decay=0.)
 seed_all(2023);start=1;best=float('inf');best_epoch=0;updates=0;seconds=0.;train_seconds=0.
 epochs=2 if smoke else 100
 if (out/'latest.pt').exists():
  state=torch.load(out/'latest.pt',map_location=device,weights_only=False);assert state['binding']==bound
  head.load_state_dict(state['head']);opt.load_state_dict(state['optimizer']);start=state['epoch']+1;updates=state['updates'];best=state['best'];best_epoch=state['best_epoch'];seconds=state['seconds'];train_seconds=state['train_seconds']
  torch.set_rng_state(state['rng_cpu'].cpu());np.random.set_state(state['rng_numpy'])
  if device.type=='cuda':torch.cuda.set_rng_state(state['rng_cuda'].cpu(),device)
 training_started=time.perf_counter();prefix_seconds=0.
 for epoch in range(start,epochs+1):
  head.train();frozen.eval();epoch_started=time.perf_counter();loss_sum=0.;count=0;fingerprint=hashlib.sha256()
  for truth,seen,starts in data.batches('train',128,epoch=epoch-1,seed=2023,max_batches=1 if smoke else None):
   fingerprint.update(starts.tobytes());fingerprint.update(seen.numpy().tobytes())
   truth=truth.to(device);seen=seen.to(device);safe=torch.where(seen,truth,0.);opt.zero_grad(set_to_none=True)
   t0=time.perf_counter();coarse=frozen(safe,seen,starts,training=True);sync(device);prefix_seconds+=time.perf_counter()-t0
   pred=head(coarse,safe,seen);valid=torch.from_numpy(data.valid_for(starts)).to(device)
   a=(pred-truth).abs();hidden=~seen&valid
   loss=a[hidden].mean() if hidden.any() else a.sum()*0.
   tail=hidden[:,-32:]
   loss=loss+.25*(a[:,-32:][tail].mean() if tail.any() else a.sum()*0.)
   assert torch.isfinite(loss);loss.backward()
   if count==0:assert all(torch.isfinite(p.grad).all() for p in head.parameters() if p.grad is not None)
   opt.step();loss_sum+=float(loss.detach());count+=1;updates+=1
  assert count==(1 if smoke else len(data.starts['train'])//128)
  sync(device);epoch_training=time.perf_counter()-epoch_started;train_seconds+=epoch_training
  assert state_hash(frozen)==frozen_digest and all(not p.requires_grad and p.grad is None for p in frozen.parameters())
  val,_=evaluate(frozen,head,data,'validation',device,cached=cache,max_batches=1 if smoke else None)
  if val['ogrr']['mae']<best:
   best=val['ogrr']['mae'];best_epoch=epoch;save(out/'selected.pt',dict(head=head.state_dict(),epoch=epoch,validation=val,binding=bound))
  elapsed=seconds+time.perf_counter()-training_started
  row=dict(status='training',epoch=epoch,updates=updates,batch_fingerprint=fingerprint.hexdigest(),training_loss=loss_sum/count,validation=val,best_epoch=best_epoch,epoch_seconds=time.perf_counter()-epoch_started,training_seconds=train_seconds,elapsed_seconds=elapsed,backbone_frozen_verified=True,resources=resource(device))
  write(out/'epochs'/f'{epoch:03}.json',row);write(out/'status.json',row)
  save(out/'latest.pt',dict(head=head.state_dict(),optimizer=opt.state_dict(),epoch=epoch,updates=updates,best=best,best_epoch=best_epoch,seconds=elapsed,train_seconds=train_seconds,binding=bound,rng_cpu=torch.get_rng_state(),rng_numpy=np.random.get_state(),rng_cuda=torch.cuda.get_rng_state(device) if device.type=='cuda' else None))
  print(json.dumps(dict(case=key,epoch=epoch,best_epoch=best_epoch,mae=val['ogrr']['mae'],seconds=row['epoch_seconds'])),flush=True)
 assert updates==epochs*(1 if smoke else len(data.starts['train'])//128)
 selected=torch.load(out/'selected.pt',map_location=device,weights_only=False);head.load_state_dict(selected['head']);head.eval()
 restored=OGRR(data).to(device).eval();restored.load_state_dict(selected['head'])
 # Use a fresh fixed validation batch for final export verification.
 b0,t0,m0,st0=cache[0];b0=b0.to(device);t0=t0.to(device);m0=m0.to(device)
 with torch.no_grad():assert torch.equal(head(b0,t0,m0),restored(b0,t0,m0))
 del restored
 if smoke:
  write(out/'complete.json',dict(status='smoke_passed',epochs=epochs,updates=updates,export_exact=True,backbone_frozen=True,selected_sha256=sha(out/'selected.pt')));return
 write(out/'training_complete.json',dict(epochs=epochs,updates=updates,selected_epoch=best_epoch,seconds=seconds+time.perf_counter()-training_started,train_seconds=train_seconds,prefix_seconds_current_process=prefix_seconds,resources=resource(device),frozen_before=frozen_digest,frozen_after=state_hash(frozen)))
 write(out/'status.json',dict(status='testing',completed_masks=0,total_masks=len(data.test_seeds)))
 results=[]
 for mask_seed in data.test_seeds:
  p=out/'test_masks'/f'{mask_seed}.json'
  if p.exists():row=json.loads(p.read_text())
  else:
   row,_=evaluate(frozen,head,data,'test',device,mask_seed=mask_seed);row['mask_seed']=mask_seed;write(p,row)
  results.append(row);write(out/'status.json',dict(status='testing',completed_masks=len(results),total_masks=len(data.test_seeds)))
 summary={}
 for stage in ['raw','ogrr']:
  summary[stage]={}
  for metric_name in ['mse','mae']:
   numbers=[x[stage][metric_name] for x in results];summary[stage][metric_name]=float(np.mean(numbers));summary[stage][metric_name+'_mask_std_ddof1']=float(np.std(numbers,ddof=1))
 summary['paired']={}
 for metric_name in ['mse','mae']:
  diff=[x['raw'][metric_name]-x['ogrr'][metric_name] for x in results]
  summary['paired'][metric_name]=dict(raw_minus_ogrr_mean=float(np.mean(diff)),mask_sample_std=float(np.std(diff,ddof=1)),relative_reduction_pct=100*(summary['raw'][metric_name]-summary['ogrr'][metric_name])/summary['raw'][metric_name],positive_masks=sum(x>0 for x in diff))
 times=[]
 with torch.no_grad():
  for i in range(30):
   sync(device);began=time.perf_counter();head(b0,t0,m0);sync(device)
   if i>=5:times.append((time.perf_counter()-began)*1000)
 summary.update(case=case,binding=bound,epochs=epochs,selected_epoch=best_epoch,updates=updates,test_masks=len(results),per_mask=results,ogrr_added_latency_p50_ms=statistics.median(times),latency_batch_size=len(b0),latency_definition='OGRR only with fixed coarse input; 5 warmups,25 synchronized measurements',ogrr_parameters=sum(p.numel() for p in head.parameters()),backbone_parameters=sum(p.numel() for p in frozen.parameters()),resources=resource(device),process_seconds=time.perf_counter()-process,backbone_frozen_verified=state_hash(frozen)==frozen_digest)
 write(out/'results.json',summary);write(out/'complete.json',dict(status='complete',epochs=epochs,updates=updates,selected_epoch=best_epoch,test_masks=len(results),frozen_verified=True,selected_sha256=sha(out/'selected.pt'),results_sha256=sha(out/'results.json')))
 write(out/'status.json',dict(status='complete',raw=summary['raw'],ogrr=summary['ogrr']))
 print('COMPLETE',key,summary['raw'],summary['ogrr'],flush=True)

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--case',required=True);p.add_argument('--device',default='cuda:0');p.add_argument('--smoke',action='store_true');a=p.parse_args()
 try:run(a.case,a.device,a.smoke)
 except BaseException:
  folder=ROOT/('smoke' if a.smoke else 'runs')/a.case;write(folder/'status.json',dict(status='failed',traceback=traceback.format_exc()));raise
