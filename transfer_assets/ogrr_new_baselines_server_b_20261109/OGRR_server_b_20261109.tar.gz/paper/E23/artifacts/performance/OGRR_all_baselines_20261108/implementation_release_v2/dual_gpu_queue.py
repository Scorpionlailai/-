"""One serial subprocess worker per GPU, resumable and isolated per case."""
import argparse,json,subprocess,sys,time,fcntl,traceback
from pathlib import Path
import numpy as np
from common import ROOT,sha,write,dataset,verify_original_masks
from summarize import summarize
from provenance import verify_finished

def reuse(c):
 source=Path(c['reuse']);d=json.loads(source.read_text());out=ROOT/'runs'/c['key'];out.mkdir(parents=True,exist_ok=True)
 data=dataset(c['dataset'],c['scene'],c.get('data_root'),c.get('data_source_root'),c.get('data_package'))
 alignment=verify_original_masks(data,c)
 if alignment:write(out/'original_mask_alignment.json',alignment)
 raw=d['coarse']['full96'];final=d['final']['full96']
 result=dict(case=c,reused=True,reuse_source=str(source),reuse_source_sha256=sha(source),reuse_files={str(source):sha(source),**{str(c[k]):sha(c[k]) for k in ['checkpoint'] if c.get(k)}},test_masks=20,epochs=100,raw={m:raw[m+'_mean'] for m in ['mse','mae']},ogrr={m:final[m+'_mean'] for m in ['mse','mae']},original_per_mask=d['per_mask'])
 assert len(d['per_mask'])==20
 assert [x['mask_seed'] for x in d['per_mask']]==data.test_seeds,'reused test masks differ'
 # Bind the original archived code, selected OGRR head, data and masks as well
 # as the published metric file; no result is accepted from a bare table.
 from provenance import bind_files
 result['reuse_files'].update(bind_files(c,data))
 original_root=source.parent
 for p in original_root.rglob('*'):
  if p.is_file() and p.suffix in ['.pt','.json','.py','.yaml']:result['reuse_files'][str(p)]=sha(p)
 result['paired']={m:dict(raw_minus_ogrr_mean=float(np.mean([x['coarse']['full96'][m]-x['final']['full96'][m] for x in d['per_mask']]))) for m in ['mse','mae']}
 write(out/'results.json',result);write(out/'complete.json',dict(status='reused',source=str(source),head_seed=2023,test_masks=20,results_sha256=sha(out/'results.json')));write(out/'status.json',dict(status='reused'))

def run(gpu,slot,datasets=None):
 torch_python=sys.executable;script=Path(__file__).parent/'run_case.py'
 lock=(ROOT/f'worker_{slot}.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 cases=json.loads((ROOT/'cases.json').read_text());eligible=[c for c in cases if c['status'] in ['ready','reused'] and (not datasets or c['dataset'] in datasets)]
 # Finish the ordinary deterministic initializers before long diffusion jobs.
 eligible.sort(key=lambda c:c['model']=='CSDI')
 jobs=eligible[slot::2];(ROOT/'logs').mkdir(exist_ok=True)
 write(ROOT/f'worker_{slot}_status.json',dict(status='started',gpu=gpu,cases=len(jobs)))
 for c in jobs:
  write(ROOT/f'worker_{slot}_status.json',dict(status='running',gpu=gpu,case=c['key'],time=time.time()))
  try:
   if verify_finished(c,ROOT/'runs'/c['key']):continue
   if c['status']=='reused':reuse(c)
   else:
    log=ROOT/'logs'/(c['key'].replace('/','__')+'.log')
    with log.open('a') as f:
     # Each case first passes validation-only short training and export.
     cmd=[torch_python,str(script),'--case',c['key'],'--device',f'cuda:{gpu}']
     if not verify_finished(c,ROOT/'smoke'/c['key'],True):
      p=subprocess.run(cmd+['--smoke'],stdout=f,stderr=subprocess.STDOUT)
      if p.returncode:raise RuntimeError('validation-only smoke failed; see '+str(log))
     p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
     if p.returncode:raise RuntimeError('case failed; see '+str(log))
  except Exception as e:
   with (ROOT/'queue_failures.jsonl').open('a') as f:f.write(json.dumps(dict(case=c['key'],error=repr(e),time=time.time(),traceback=traceback.format_exc()))+'\n')
  # Serialize the shared aggregate to avoid cross-worker partial writes.
  with (ROOT/'summary.lock').open('a') as f:
   fcntl.flock(f,fcntl.LOCK_EX);summarize()
 write(ROOT/f'worker_{slot}_status.json',dict(status='available_jobs_finished',gpu=gpu,pending_external_assets=sum('missing' in c['status'] for c in cases)))

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--gpu',type=int,required=True);p.add_argument('--slot',type=int,choices=[0,1],required=True);p.add_argument('--datasets',nargs='+');a=p.parse_args();run(a.gpu,a.slot,a.datasets)
