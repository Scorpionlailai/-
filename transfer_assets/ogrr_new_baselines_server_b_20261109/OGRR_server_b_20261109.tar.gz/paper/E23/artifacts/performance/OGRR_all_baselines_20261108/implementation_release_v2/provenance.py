"""Verify all inputs to completed/resumed jobs, including original source bytes."""
from pathlib import Path
import json
import torch,numpy as np
from common import ROOT,DONOR,sha,bootstrap

def _files(roots):
 out=set()
 for root in roots:
  root=Path(root)
  if root.is_file():out.add(root.resolve())
  elif root.exists():
   out.update(p.resolve() for p in root.rglob('*') if p.is_file() and p.suffix in ['.py','.yaml','.yml','.json'] and '__pycache__' not in p.parts and '.git' not in p.parts)
 return out

def bind_files(case,data=None):
 bootstrap.verify_sources()
 paths=_files([Path(__file__).parent,DONOR,DONOR.parent/'T1_settings.json'])
 for key in ['checkpoint','runner','source_root','data_source_root','config_path','selection_path','original_result_path','asset_row_path','recovery_source']:
  if case.get(key):paths.update(_files([case[key]]))
 if case.get('profile',{}).get('root'):paths.update(_files([case['profile']['root']]))
 if case['model']=='T1':paths.update(_files(['/home/xyw/paper/T1']))
 if case['model']=='BRITS':paths.add(Path('/home/xyw/paper/E24/integrations/forecast_compare/author_profiles.py'))
 root=Path(case.get('data_root','/home/xyw/r3_release_20261030' if case['dataset']=='PhysioNet2012' else '/home/xyw/paper'))
 files={'ETTh1':['data/raw/ETTh1.csv'],'Weather':['data/raw/weather.csv'],'Exchange-Rate':['data/raw/Exchange-Rate/exchange_rate.txt'],'BeijingAirQuality':['data/processed/beijing_pm25_12stations.csv','data/processed/beijing_pm25_12stations.natural_missing.npz'],'PAMAP2':['data/processed/pamap2_10hz_recordwise/manifest.json'],'PhysioNet2012':['data/processed/physionet_15min_recordwise/manifest.json']}[case['dataset']]
 for rel in files:
  p=root/rel;paths.add(p)
  if p.name=='manifest.json':
   meta=json.loads(p.read_text())
   for name in meta.get('files',{}):paths.add(p.parent/name)
 if data is not None:
  paths.add(data.assets/'manifest.json');paths.update(data.assets.glob('*.npz'))
 if case.get('mask_root'):paths.update(Path(case['mask_root']).glob('*.npz'))
 # Donor source is immutable, including its vendor lock; mutable result/status
 # files outside source trees never enter a model's binding.
 for key,expected in case.get('source_expected',{}).items():
  p=Path(case['source_root'])/key
  if not p.is_file() or sha(p)!=expected:raise ValueError('original source mismatch: '+str(p))
 return {str(p.resolve()):sha(p) for p in sorted(paths) if p.is_file()}

def make_binding(case,data,smoke):
 return dict(case=case,dataset_manifest=data.manifest_sha,files=bind_files(case,data),environment=dict(torch=torch.__version__,numpy=np.__version__,cuda=torch.version.cuda),epochs=2 if smoke else 100,head_seed=2023,batch_size=128,loss='native-valid hidden full96 MAE + .25 last32 MAE',selection='validation full96 MAE',smoke=smoke)

def verify_finished(case,out,smoke=False):
 out=Path(out)
 if not (out/'complete.json').exists():return False
 done=json.loads((out/'complete.json').read_text())
 if done.get('status')=='reused':
  record=json.loads((out/'results.json').read_text())
  assert record['case']==case,'reused case changed'
  for path,digest in record['reuse_files'].items():assert sha(path)==digest,'reused provenance changed: '+path
  assert sha(out/'results.json')==done['results_sha256'],'reused summary changed'
 else:
  binding=json.loads((out/'binding.json').read_text());assert binding['case']==case and binding['smoke']==smoke,'finished case changed'
  for path,digest in binding['files'].items():assert sha(path)==digest,'finished source/data changed: '+path
  assert binding['environment']==dict(torch=torch.__version__,numpy=np.__version__,cuda=torch.version.cuda),'runtime changed'
  assert sha(out/'selected.pt')==done['selected_sha256'],'selected head changed'
  if not smoke:assert sha(out/'results.json')==done['results_sha256'],'finished result changed'
 return True
