from pathlib import Path
import itertools,json,csv
from common import ROOT,sha,write
from backbones import EX
DATASETS=['Exchange-Rate','ETTh1','BeijingAirQuality','Weather','PAMAP2','PhysioNet2012']
SCENES=['sr015_bl8','sr010_bl8','sr020_bl8','sr010_bl16']
MODELS=['TimesNet','T1','ZERO','INTERPOLATION','BRITS','ImputeFormer','CSDI']
WEATHER=Path('/home/xyw/paper/E24/artifacts/Weather/seq96_pred96')

def make_cases():
 cases=[]
 for d,s,m in itertools.product(DATASETS,SCENES,MODELS):
  c=dict(key='/'.join([d,s,m]),dataset=d,scene=s,model=m,head_seed=2023,status='missing_original_weight')
  if m in ['ZERO','INTERPOLATION']:
   c['status']='ready'
   if d=='BeijingAirQuality' and s=='sr020_bl8':
    old='S0' if m=='ZERO' else 'S1'
    p=Path('/home/xyw/paper/E23/artifacts/performance/Beijing_sr020_S0_S1_fine_recovery_20261101/outputs')/old/'results.json'
    if p.exists():c.update(status='reused',reuse=str(p))
  elif d=='Exchange-Rate':
   b=EX/('csdi_budget_100ep_train1_eval5_20261010' if m=='CSDI' else 'v125_baselines_20261010')
   c.update(checkpoint=str(b/'runs'/m/s/'stage1/selected.pt'),runner=str(b/'runners'/m))
   p=b/'runners'/m/'profiles.json'
   if p.exists():c['profile']=json.loads(p.read_text())['models'][m]
  elif d=='Weather' and m=='T1':
   roots={'sr010_bl8':'weather_author_comparison_20261008','sr015_bl8':'weather_author_comparison_sr015_20261008','sr020_bl8':'weather_author_comparison_sr020_20261008','sr010_bl16':'weather_author_comparison_sr010_bl16_20261008'}
   c.update(checkpoint=str(WEATHER/s/roots[s]/m/'stage1/selected.pt'),profile={'training':{'precision':'float32'}})
  elif d=='BeijingAirQuality' and s=='sr020_bl8' and m=='T1':
   b=Path('/home/xyw/paper/E23/artifacts/performance/Beijing_sr020_T1_R3_calibration_20261101')
   c.update(checkpoint=str(b/'original_T1/stage1/selected.pt'),reuse=str(b/'outputs/results.json'),reuse_resources=str(b/'outputs/resources.json'))
  if 'checkpoint' in c and Path(c['checkpoint']).is_file():
   c.update(status='reused' if 'reuse' in c else 'ready',checkpoint_sha256=sha(c['checkpoint']))
  if d=='PhysioNet2012':
   processed=Path('/home/xyw/r3_release_20261030/data/processed/physionet_15min_recordwise')
   missing=[str(processed/f) for f in ['values.npy','native_observed.npy','elapsed_seconds.npy'] if not (processed/f).exists()]
   if missing:
    c['missing_data']=missing
    c['status']='missing_data' if c['status']=='ready' else 'missing_original_weight_and_data'
  cases.append(c)
 # Optional sync registry explicitly binds every supplied asset, never substitutes silently.
 registry=ROOT/'received_assets.json'
 if registry.exists():
  supplied=json.loads(registry.read_text())
  for c in cases:
   if c['key'] in supplied:
    c.update(supplied[c['key']]);assert sha(c['checkpoint'])==c['checkpoint_sha256'];c['status']='reused' if c.get('reuse') else 'ready'
 # Original model banks are also used for the two observation-only controls.
 for c in cases:
  if c['dataset']=='Exchange-Rate':continue
  original=next((x for x in cases if x['dataset']==c['dataset'] and x['scene']==c['scene'] and x['model']=='TimesNet'),None)
  if original and original.get('mask_root') and not c.get('mask_root'):c['mask_root']=original['mask_root']
  if original and original.get('source_root'):
   c['data_source_root']=original['source_root'];c['data_package']=original['original_adapter']
  if c['dataset']=='BeijingAirQuality':c['data_root']='/home/xyw/r3_release_20261030'
  if c['dataset']=='PhysioNet2012':
   data_root=ROOT/'prepared_data'
   if (data_root/'data/processed/physionet_15min_recordwise/manifest.json').exists():
    c['data_root']=str(data_root);c.pop('missing_data',None)
    c['status']='ready' if c['model'] in ['ZERO','INTERPOLATION'] or c.get('checkpoint') else 'missing_original_weight'
   else:c['status']='missing_data'
 write(ROOT/'cases.json',cases)
 with (ROOT/'asset_availability.csv').open('w',newline='') as f:
  fields=['dataset','scene','model','status','checkpoint','checkpoint_sha256'];w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(cases)
 print({k:sum(c['status']==k for c in cases) for k in sorted(set(c['status'] for c in cases))})
 return cases
if __name__=='__main__':make_cases()
