"""Original frozen baseline builders and observation-only initializers."""
from pathlib import Path
import json,importlib,importlib.util,sys,types,inspect,ast
import numpy as np
from typing import Union,Tuple,List
import torch
from torch import nn
from common import interpolate,DONOR

EX=Path('/home/xyw/paper/E23/artifacts/Exchange-Rate/seq96_pred96/experiments')
def module(path,name):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m

def execute_source(path,namespace,remove=()):
 text=path.read_text()
 for line in remove:
  assert line in text; text=text.replace(line,'')
 exec(compile(text,str(path),'exec'),namespace);return namespace

def original_dependencies(name,root,config):
 """Load the exercised author NN code without unused training-framework imports."""
 if name=='BRITS':
  source=Path('/home/xyw/paper/E24/integrations/forecast_compare/author_profiles.py')
  tree=ast.parse(source.read_text());nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in ['_module','_OriginalBRITS']]
  helper=types.ModuleType('integrations.forecast_compare.author_profiles');helper.__file__=str(source)
  helper.__dict__.update(torch=torch,nn=nn,Path=Path,ModuleType=types.ModuleType,sys=sys)
  exec(compile(ast.fix_missing_locations(ast.Module(body=nodes,type_ignores=[])),str(source),'exec'),helper.__dict__)
  sys.modules[helper.__name__]=helper
 elif name=='ImputeFormer':
  source=root/'ImputeFormer/experiments'
  functional=source/'tsl/nn/functional.py'
  node=next(n for n in ast.parse(functional.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='expand_then_cat')
  scope=dict(np=np,torch=torch,Tensor=torch.Tensor,Union=Union,Tuple=Tuple,List=List)
  exec(compile(ast.Module(body=[node],type_ignores=[]),str(functional),'exec'),scope)
  u=execute_source(source/'tsl/nn/utils/utils.py',{'expand_then_cat':scope['expand_then_cat']},('from ..ops import expand_then_cat',));utils=types.SimpleNamespace(**u)
  dense=execute_source(source/'tsl/nn/base/dense.py',{'utils':utils},('from tsl.nn.utils import utils',))['Dense']
  mlp=execute_source(source/'tsl/nn/blocks/encoders/mlp.py',{'Dense':dense,'utils':utils},('from ...base.dense import Dense','from ...utils import utils'))['MLP']
  att=execute_source(source/'imputeformer/models/Attention_layers.py',{})
  ns={'utils':utils,'MLP':mlp,**{k:att[k] for k in ['AttentionLayer','SelfAttentionLayer','EmbeddedAttention']}}
  original=source/'imputeformer/models/ImputeFormer.py'
  ns=execute_source(original,ns,('from tsl.nn import utils','from tsl.nn.blocks.encoders import MLP','from .Attention_layers import AttentionLayer, SelfAttentionLayer, EmbeddedAttention'))
  obj=types.ModuleType('imputeformer.models.ImputeFormer');obj.__file__=str(original);obj.ImputeFormerModel=ns['ImputeFormerModel'];sys.modules[obj.__name__]=obj
 elif name=='CSDI':
  assert not config['diffusion']['is_linear'],'linear-attention dependency is required for that architecture'
  source=root/'CSDI'
  ns=execute_source(source/'diff_models.py',{'__name__':'_ogrr_original_diff'},('from linear_attention_transformer import LinearAttentionTransformer',))
  obj=types.ModuleType('main_model');obj.__file__=str(source/'main_model.py');obj.diff_CSDI=ns['diff_CSDI']
  execute_source(source/'main_model.py',obj.__dict__,('from diff_models import diff_CSDI',));sys.modules['main_model']=obj

def build(case,data,device):
 name=case['model']
 if name in ['ZERO','INTERPOLATION']:return FrozenInitializer(name,data).to(device)
 meta=torch.load(case['checkpoint'],map_location='cpu',weights_only=False)
 state=meta.get('model_state',meta.get('model',meta))
 cfg=case.get('profile')
 if case.get('original_adapter') and name!='T1':
  root=Path(case['source_root']);package='_ogrr_original'
  original_dependencies(name,root,cfg['model'])
  pkg=types.ModuleType(package);pkg.__path__=[str(root/'E24/integrations'/case['original_adapter'])];sys.modules[package]=pkg
  original_data=importlib.import_module(package+'.data');original_data.ROOT=root
  adapters=importlib.import_module(package+'.adapters')
  raw=adapters.build_adapter(name,data,device)
 elif name=='T1':
  settings=json.loads((DONOR.parent/'T1_settings.json').read_text())
  settings.update((cfg or {}).get('model',{}));settings['enc_in']=data.n_vars
  source=Path(case['source_root'])/'T1/models/T1.py' if case.get('source_root') else Path('/home/xyw/paper/T1/models/T1.py')
  raw=module(source,'_ogrr_t1').Model(types.SimpleNamespace(**settings))
  if all(k.startswith('core.') for k in state):state={k[5:]:v for k,v in state.items()}
 elif case['dataset']=='Exchange-Rate' and name in ['TimesNet','ImputeFormer','CSDI']:
  extra=module(Path(case['runner'])/'adapters/extra.py','_ogrr_extra')
  cls={'TimesNet':'TimesNetAdapter','ImputeFormer':'ImputeFormerAdapter','CSDI':'CSDIAdapter'}[name]
  raw=getattr(extra,cls)(cfg,device) if name=='CSDI' else getattr(extra,cls)(cfg)
 elif case['dataset']=='Exchange-Rate' and name=='BRITS':
  source=Path('/home/xyw/paper/E24/integrations/forecast_compare/author_profiles.py')
  tree=ast.parse(source.read_text());nodes=[n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name in ['_module','_OriginalBRITS','_original_brits']]
  text=ast.unparse(ast.Module(body=nodes,type_ignores=[]))
  assert text.count('ast.Constant(7)')==1
  namespace=dict(ast=ast,torch=torch,nn=nn,Path=Path,ModuleType=types.ModuleType,sys=sys)
  exec(compile(text.replace('ast.Constant(7)','ast.Constant(8)'),str(source),'exec'),namespace)
  raw=namespace['_original_brits'](Path(cfg['root']),cfg['model'])
  raw=module(Path(case['runner'])/'adapters/fast_brits.py','_ogrr_brits').compile_brits(raw)
 else:raise NotImplementedError('An exact original archived builder is required for '+str(case['key']))
 raw.load_state_dict(state,strict=True)
 if name=='CSDI':
  assert raw.core.num_steps==50
  if case.get('original_adapter'):
   raw.n_samples=cfg['model']['sampling']['samples'];raw.sample_chunk_size=cfg['model']['sampling']['sample_chunk_size']
  else:assert raw.sampling_count==5
 return FrozenInitializer(name,data,raw,cfg,native=bool(case.get('original_adapter')) and name!='T1').to(device)

class FrozenInitializer(nn.Module):
 def __init__(self,name,data,raw=None,cfg=None,native=False):
  super().__init__();self.name=name;self.data=data;self.raw=raw;self.cfg=cfg or {};self.native=native
  if raw is not None:raw.requires_grad_(False).eval()
 def train(self,mode=True):
  super().train(False);return self
 @torch.no_grad()
 def forward(self,values,observed,starts,training=False,mask_seed=None):
  safe=torch.where(observed,values,0.)
  if self.name=='ZERO':return safe
  if self.name=='INTERPOLATION':return interpolate(safe,observed)
  self.raw.eval()
  precision=self.cfg.get('training',{}).get('precision','float32')
  dtype={'float16':torch.float16,'float16_mixed':torch.float16,'bfloat16':torch.bfloat16}.get(precision)
  count_key='n_samples' if self.native else 'sampling_count'
  count=getattr(self.raw,count_key,None)
  if self.name=='CSDI' and training:setattr(self.raw,count_key,1)
  try:
   with torch.autocast('cuda',dtype=dtype,enabled=values.is_cuda and dtype is not None):
    if self.native:
     parts=[];batch=self.cfg['training']['batch_size']
     for i in range(0,len(safe),batch):
      if self.name=='CSDI':
       with torch.random.fork_rng(devices=[values.device.index or 0] if values.is_cuda else []):
        torch.manual_seed(910000+(mask_seed or 2021)+int(starts[i]))
        part=self.raw(safe[i:i+batch],observed[i:i+batch],starts[i:i+batch])
      else:part=self.raw(safe[i:i+batch],observed[i:i+batch],starts[i:i+batch])
      parts.append(part.float())
     result=torch.cat(parts)
    elif self.name=='CSDI':
     result=torch.cat([self.raw(safe[i:i+16],mask=observed[i:i+16].to(safe.dtype)).float() for i in range(0,len(safe),16)])
    else:result=self.raw(safe,mask=observed.to(safe.dtype)).float()
  finally:
   if count is not None:setattr(self.raw,count_key,count)
  return torch.where(observed,safe,result)
